package com.orcamento.izabella;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IzabellaApplicationTests {

	@Test
	void contextLoads() {
	}

}
