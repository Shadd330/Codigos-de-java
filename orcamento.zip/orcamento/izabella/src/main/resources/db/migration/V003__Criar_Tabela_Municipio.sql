create table municipio(
id int not null primary key auto_increment,
nome varchar(100),
estado varchar(100)
);