create table lancamento(
id int not null primary key auto_increment,
datalancamento date,
id_cliente int not null,
tipolancamento varchar(100),
valorlancamento decimal(10,2)
);