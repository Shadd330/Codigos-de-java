create table cliente(
id int not null primary key auto_increment,
nome varchar(100),
endereco varchar(100),
numero varchar(100),
bairro varchar(100),
id_municipio int not null,
telefone varchar(11),
celular varchar(11)
);

alter table cliente add constraint FK_municipio_cliente foreign key (id_municipio)
references municipio(id);

alter table lancamento add constraint FK_cliente_lancamento foreign key (id_cliente)
references cliente(id);