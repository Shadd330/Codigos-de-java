package com.orcamento.izabella.estoque.Services;

import com.orcamento.izabella.estoque.Model.Municipio;
import com.orcamento.izabella.estoque.Repositories.MunicipioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MunicipioService {

@Autowired
    private MunicipioRepository municipioRepository;

public Municipio salvar(Municipio municipio ){return municipioRepository.save(municipio);}
}
