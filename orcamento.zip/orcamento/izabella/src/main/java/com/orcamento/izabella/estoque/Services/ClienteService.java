package com.orcamento.izabella.estoque.Services;

import com.orcamento.izabella.estoque.Model.Cliente;
import com.orcamento.izabella.estoque.Repositories.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClienteService {
    @Autowired
    private ClienteRepository clienteRepository;

    public Cliente salvar(Cliente cliente ){ return clienteRepository.save(cliente);}

}
