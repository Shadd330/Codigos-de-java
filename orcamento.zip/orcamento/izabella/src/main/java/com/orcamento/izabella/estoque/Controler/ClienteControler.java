package com.orcamento.izabella.estoque.Controler;


import com.orcamento.izabella.estoque.Model.Cliente;
import com.orcamento.izabella.estoque.Repositories.ClienteRepository;
import com.orcamento.izabella.estoque.Services.ClienteService;
import jdk.jfr.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping ("/Clientes")

public class ClienteControler {

    @Autowired
        private ClienteService clienteService;
        private ClienteRepository clienteRepository;

            public List<Cliente>ListarTodosClientes(){
                return clienteRepository.findAll(Sort.by("nome").ascending());
            }

    @PostMapping()
        public ResponseEntity<Cliente> inserir (@RequestBody Cliente cliente){
        Cliente cliente1 =clienteService.salvar(cliente);
        return ResponseEntity.status(HttpStatus.CREATED).body(cliente1);
    }
}
