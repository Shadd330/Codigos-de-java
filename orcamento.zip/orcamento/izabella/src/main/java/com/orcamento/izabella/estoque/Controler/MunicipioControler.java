package com.orcamento.izabella.estoque.Controler;



import com.orcamento.izabella.estoque.Model.Lancamento;
import com.orcamento.izabella.estoque.Model.Municipio;
import com.orcamento.izabella.estoque.Services.ClienteService;
import com.orcamento.izabella.estoque.Services.MunicipioService;
import jdk.jfr.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping ("/Municipios")

public class MunicipioControler {

    @Autowired
    private MunicipioService MunicipioService;

    @PostMapping()
    public ResponseEntity<Municipio> inserir (@RequestBody Municipio municipio){
        Municipio municipiosalvo = MunicipioService.salvar(municipio);
        return ResponseEntity.status(HttpStatus.CREATED).body(municipiosalvo);
    }
}
