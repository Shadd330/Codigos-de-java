package com.orcamento.izabella.estoque.Services;

import com.orcamento.izabella.estoque.Model.Lancamento;
import com.orcamento.izabella.estoque.Repositories.LancamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LancamentoService {
@Autowired
    private LancamentoRepository lancamentoRepository;

    public Lancamento salvar(Lancamento lancamento) {return lancamentoRepository.save(lancamento);}
}
