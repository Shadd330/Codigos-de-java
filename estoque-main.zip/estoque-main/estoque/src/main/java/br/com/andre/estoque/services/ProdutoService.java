package br.com.andre.estoque.services;

import br.com.andre.estoque.model.Produto;
import org.springframework.stereotype.Service;

@Service
public class ProdutoService {
    private br.com.andre.estoque.repositories.ProdutoRepository ProdutoRepository;
    public Produto salvar (Produto produto){
        return ProdutoRepository.save(produto);
    }

}
